# The ZigZag project!

The official ZigZag project!

Actually I made this to learn python &amp; Telegram bot API

But now its going furthur than learning python xD

Special thanks to Iman Daneshi that gave me the idea to learn python.. lol..

This page will get updated after the first stable release.

# Installation

To install the bot, executes theese commands one by one:

```
git clone https://github.com/WebShark025/MySimpleFirstPythonBot
cd MySimpleFirstPythonBot
chmod +x install.sh
sudo ./install.sh
```

Launch the bot once: `./launch.sh` then stop it (`Ctrl + C`)

A Copy of `locale.py.new` & `config.py.new` will be maken => `locale.py` & `config.py`. 

Edit those as you need.

Then launch the bot normaly. To do it, simply execute `./launch.sh` 

If you have problems, visit [Manual installation](https://github.com/WebShark025/MySimpleFirstPythonBot/wiki/Manual-installation)

# Commands 

| Command | Description | Permission |
|:--------|:------------|:-----------|
| /help & /start | Returns the start message | Members |
| /test & /toast | (BetaVersionsOnly) Just replies a message | Members |
| /echo text | Echoes the text | Members |
| /feedback | Sends users feedback | Members |
| /sendcontact | Sends user contact to bot admin | Members |
| /id | Sends user ID & name (if in group, groups ID too) | Members |
| /calc | Maths! :D | Members |
| /time | Returns time (in IRST) | Members |
| /support | Joines the support chat. | Members |
| /leave | Leaves the support chat. | Members |
| /adminhelp | Admin commands help | Admins |
| /members | List of members & banned users | Admins |
| /bc | Broadcast message to all members | Admins |
| /ban userid | Bans a user | Admins |
| /unban userid | Unbans a user | Admins |
| /force_user_leave userid | Forces a user to leave support chat | Admins |

More commands comming soon!

# Contact me

[![https://telegram.me/WebShark25](https://img.shields.io/badge/💬_Telegram-WebShark25-blue.svg)](https://telegram.me/WebShark25)

The ZigZag official channel in Telegram: [@TheZigZagProject](https://telegram.me/TheZigZagProject)

The ZigZag official bot in Telegram: [@TheZigZagBot](https://telegram.me/TheZigZagBot)

# Credits

Special thanks to [Iman Daneshi](https://github.com/imandaneshi) for the idea.

Thanks to [ThisIsAmirH](https://github.com/ThisIsAmir) for some part of his codes.

And thanks to [eternnoir](https://github.com/eternnoir/) for his awesome API!


